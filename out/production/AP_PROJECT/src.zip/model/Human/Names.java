package model.Human;

public enum Names {
    ARCHER,
    CROSSBOWMEN,
    SPEAR_MEN,
    PIKE_MEN,
    MACE_MEN,
    SWORDSMEN,
    KNIGHT,
    TUNNELER,
    LADDER_MEN,
    ENGINEER,
    BLACK_MONK,
    ARCHER_BOW,
    SLAVES,
    SLINGERS,
    ASSASSINS,
    HORSE_ARCHERS,
    ARABIAN_SWORDSMEN,
    FireThrowers,

}
