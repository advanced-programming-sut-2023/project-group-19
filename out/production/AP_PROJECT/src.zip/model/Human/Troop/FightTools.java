package model.Human.Troop;

import model.Empire;

public class FightTools extends Army{
    public FightTools(Empire government) {
        super(government);
    }
    public void portableShield(){

    }
    public void ram(){

    }
    public void conquerTower(){

    }
    public void normalCatapult(){

    }
    public void specialCatapult(){

    }
    public void fireThrower(){

    }



}
