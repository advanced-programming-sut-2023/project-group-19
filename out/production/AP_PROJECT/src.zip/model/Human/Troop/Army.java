package model.Human.Troop;

import model.Empire;
import model.Human.Human;

public class Army extends Human {
    public Army(Empire government) {
        super(government);
    }
    private String armyForm;

    public String getArmyForm() {
        return armyForm;
    }

    public void setArmyForm(String armyForm) {
        this.armyForm = armyForm;
    }
}
