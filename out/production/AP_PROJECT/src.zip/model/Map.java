package model;

import model.Building.Building;
import model.Human.Troop.Army;
import model.Obstacle.Obstacle;

import java.util.ArrayList;

public class Map {
    public static ArrayList<Building>[][] buildingMap;
    public static ArrayList<Army>[][] troopMap;
    public static ArrayList<Obstacle>[][] obstacleMap;
    public static ArrayList<String>[][] groundType;
    public static boolean[][] notPassable; // for troop
    public static boolean[][] notBuildable; // for building

    public static void CreateMap(int size){
        ArrayList<Building>[][] buildingMap = new ArrayList[size][size];
        for(int i = 0 ; i < size ; i++){
            for(int j = 0 ; j < size ; j++){
                buildingMap[i][j] = new ArrayList();
            }
        }
        ArrayList<Army>[][] troopMap = new ArrayList[size][size];
        for(int i = 0 ; i < size ; i++){
            for(int j = 0 ; j < size ; j++){
                troopMap[i][j] = new ArrayList();
            }
        }
        ArrayList<Army>[][] obstacleMap = new ArrayList[size][size];
        for(int i = 0 ; i < size ; i++){
            for(int j = 0 ; j < size ; j++){
                obstacleMap[i][j] = new ArrayList();
            }
        }
        ArrayList<String>[][] groundType = new ArrayList[size][size];
        for(int i = 0 ; i < size ; i++){
            for(int j = 0 ; j < size ; j++){
                groundType[i][j] = new ArrayList();
            }
        }
        boolean[][] notPassable = new boolean[size][size];
        boolean[][] notBuildable = new boolean[size][size];
    }

}
