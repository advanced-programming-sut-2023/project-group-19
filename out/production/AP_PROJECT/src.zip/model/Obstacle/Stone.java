package model.Obstacle;

import model.Human.Names;

public class Stone extends Obstacle {
    //TODO army can not pass from stones
    public void stone(){
        name = ObstacleName.STONE;
    }
}
