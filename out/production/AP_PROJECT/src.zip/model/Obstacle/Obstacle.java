package model.Obstacle;

public abstract class Obstacle {
    protected ObstacleName name;

    public ObstacleName getName() {
        return name;
    }

}
