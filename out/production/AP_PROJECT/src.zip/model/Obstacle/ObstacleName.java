package model.Obstacle;

public enum ObstacleName {
    DESERT_TREE,
    CherryTree,
    OliveTree,
    CoconutTree,
    DateTree,
    PETROL,
    PLAIN,
    BIG_POND,
    SMALL_POND,
    BEACH,
    SEA,
    RIVER,
    SHALLOW_WATER,
    STONE,

}
