package model;

public class FightWays {
    public void fillTheDitch(){

    }
    public void conquerTheGate(){

    }
}
