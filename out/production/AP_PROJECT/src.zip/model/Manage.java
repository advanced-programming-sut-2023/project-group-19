package model;

import java.util.ArrayList;

public class Manage {
    public static ArrayList<Empire> allEmpires = new ArrayList<>();

}
