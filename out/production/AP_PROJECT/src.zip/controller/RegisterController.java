package controller;
import model.*;

import java.util.Scanner;

public class RegisterController {
    public static String currentMenu;
    static User isUser ;

    public static void run(Scanner scanner){

    }
    public void createUser(){

    }
    public User getUserByName(){
        return isUser ;
    }
}
