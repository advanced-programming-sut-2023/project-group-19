package controller;
import model.*;

import java.util.Scanner;

public class MainMenuController {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void getMenuToEnterIt(){

    }
    public String printTextToShowState(){
        return null ;
    }
}
