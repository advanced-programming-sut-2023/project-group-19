package controller;
import model.*;
import java.util.Scanner;

public class TradeController {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void setRequest(){

    }
    public void getRequest(){

    }

}
