package controller;
import model.*;

import java.util.Scanner;

public class ShopController {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void getGoodsFromShopMenu(){

    }
    public void makeGoodsFromShopMenu(){

    }
}
