package controller;
import model.*;

import java.util.Scanner;

public class LoginController {
    static User currentUser ;
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void setUser(){

    }
    public void setCurrentUser(){

    }
    public void createUser(){

    }
}
