package controller;
import model.*;

import java.util.Scanner;

public class CreateMapController {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void createMap(){

    }
    public void lookMap(){

    }
}
