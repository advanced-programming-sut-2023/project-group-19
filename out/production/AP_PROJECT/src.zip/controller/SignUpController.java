package controller;
import model.*;

import java.util.Scanner;

public class SignUpController {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public static void createUser(){

    }
}
