package view;

import model.Empire;
import model.User;

import java.util.Scanner;

public class GameMenu {
    public static User currentUser;
    public static Empire currentEmpire;
    public void run(Scanner scanner){
        while(true){

        }
    }
    public void switchTurn(){

    }
    public void fight(){

    }
    public void defend(){

    }
    public void moveSoldier(){

    }
    public void findBestRoute(){

    }
}
