package view;
import controller.*;
import java.util.Scanner;

public class SignUpMenu {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void registerUserName(){

    }
    public void searchToWholeUserNames(){

    }
    public void checkPassword(){

    }
}
