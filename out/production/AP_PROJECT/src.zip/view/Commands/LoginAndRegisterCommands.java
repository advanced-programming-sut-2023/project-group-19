package view.Commands;

public enum LoginAndRegisterCommands {
    //TODO CLASS FOR COMMANDS REGEX
}
