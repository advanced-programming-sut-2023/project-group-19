package view.Commands;

public enum ProfileMenuCommands {
    //TODO CLASS FOR COMMANDS REGEX
}
