package view.Commands;

public enum MainMenuCommands {
    //TODO CLASS FOR COMMANDS REGEX
}
