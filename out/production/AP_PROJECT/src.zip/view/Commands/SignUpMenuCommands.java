package view.Commands;

public enum SignUpMenuCommands {
    //TODO CLASS FOR COMMANDS REGEX
}
