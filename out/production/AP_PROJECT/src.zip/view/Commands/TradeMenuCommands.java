package view.Commands;

public enum TradeMenuCommands {
    //TODO CLASS FOR COMMANDS REGEX
}
