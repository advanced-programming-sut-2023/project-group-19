package view.Commands;

public enum ShopMenuCommands {
    //TODO CLASS FOR COMMANDS REGEX
}
