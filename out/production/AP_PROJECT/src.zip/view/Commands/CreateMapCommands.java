package view.Commands;

public enum CreateMapCommands {
    //TODO CLASS FOR COMMANDS REGEX
}
