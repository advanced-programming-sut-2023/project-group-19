package view;
import controller.*;

import java.util.Scanner;

public class LoginMenu {
    public static void run(Scanner scanner){
        while(true){

        }
    }


    public void checkForLogin(){

    }
    public void checkForRegister(){

    }
    public void enterToLoginUser(){

    }

}
