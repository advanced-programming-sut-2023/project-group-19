package view;
import controller.*;
import java.util.Scanner;


public class TradeMenu {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void getEmpire(){

    }
    public void getGoodsFromEmpire(){

    }
    public void requestToGetGoods(){

    }
}
