package view;

import model.Map;
import controller.*;

import java.util.Scanner;

public class CreateMapMenu {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }

    public void lookAfterLocation(){

    }
    public void makeAnObstacle(){

    }
    public String getNameOfAnClass(int x , int y){
        return null ;
    }
    public void initializeTheMap(){

    }
}
