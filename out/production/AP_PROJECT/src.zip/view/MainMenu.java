package view;
import controller.*;
import java.util.Scanner;

public class MainMenu {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void enterCreateMapMenu(){

    }
    public void enterLoginMenu(){

    }
    public void enterProfileMenu(){

    }
    public void enterShopMenu(){

    }
    public void enterSignUpMenu(){

    }
    public void enterTradeMenu(){

    }

}
