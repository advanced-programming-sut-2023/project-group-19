package view;
import controller.*;
import java.util.Scanner;

public class ShopMenu {
    public static String currentMenu;

    public static void run(Scanner scanner){

    }
    public void showGoods(){

    }
    public void buyGoods(){

    }
    public void goToNextItem(){

    }
    public void goBeforeItem(){

    }
}
